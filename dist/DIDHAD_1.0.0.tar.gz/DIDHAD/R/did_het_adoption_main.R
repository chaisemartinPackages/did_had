#' Inner main function for DIDHetAdoption package
#' @param df A data.frame object
#' @param outcome Outcome variable
#' @param treatment Treatment variable
#' @param group Group Variable
#' @param level level
#' @importFrom plm pdata.frame make.pbalanced
#' @importFrom stats lm qnorm as.formula
#' @import lpdensity
#' @noRd
did_het_adoption_main <- function(
    df,
    outcome,
    group,
    time,
    treatment,
    level
) {

    df <- df[c(outcome, group, time, treatment)]
    short_vars <- list(outcome = "Y", treatment = "D", group = "group", time = "time")
    for (v in c("outcome", "treatment", "group", "time")) {
        df[[paste0(short_vars[[v]],"_XX")]] <- as.numeric(df[[get(v)]])
        df <- subset(df, !is.na(df[[paste0(short_vars[[v]],"_XX")]]))
    }

    df <- df[order(df$group_XX, df$time_XX), ]
    df <- pdata.frame(df, index = c("group_XX", "time_XX")) 
    df <- make.pbalanced(df, balance.type = "fill")

    if (length(levels(df$time_XX)) > 1) {
        # Complete with "keeping only the observation at the second period"
        df$diff_Y_XX <- diff(df$Y_XX, na.rm = TRUE)
        df <- subset(df, df$time_XX == max(df$time_XX, na.rm = TRUE))
    } else {
        df$diff_Y_XX <- df$Y_XX
    }
    rownames(df) <- 1:nrow(df)

    for (j in c(2,3,4)) {
        df[[paste0("D_",j,"_XX")]] <- df$D_XX^j
    }
    df$diff_Y_2_XX <- df$diff_Y_XX^2

    h_star_scalars <- c()

    ## f''(0)
    h <- 0.5;
    for (j in 0:1) {
        h <- cross_validation(as.formula("diff_Y_XX ~ D_XX + D_2_XX"),"D_XX", "diff_Y_XX", df, h, 10^(-j))
    }
    bw1 <- quantile(df$D_XX,h,type=2)
    f_2_prime <- 2 * lm(diff_Y_XX ~ D_XX + D_2_XX, data = subset(df, df$D_XX < quantile(df$D_XX,h,type=2)))$coefficients[["D_2_XX"]]
    h_star_scalars <- c(h_star_scalars, f_2_prime)

    ## sigma^2(0)
    h <- 0.5;
    for (j in 0:1) {
        h <- cross_validation(as.formula("diff_Y_2_XX ~ D_XX"),"D_XX", "diff_Y_XX", df, h, 10^(-j))
    }
    bw2 <- quantile(df$D_XX,h,type=2)
    reg_1 <- lm(diff_Y_2_XX ~ D_XX, data = subset(df, df$D_XX < quantile(df$D_XX,h,type=2)))$coefficients[["(Intercept)"]]
    h <- 0.5;
    for (j in 0:1) {
        h <- cross_validation(as.formula("diff_Y_XX ~ D_XX"),"D_XX", "diff_Y_XX", df, h, 10^(-j))
    }
    bw3 <- quantile(df$D_XX,h,type=2)
    reg_2 <- (lm(diff_Y_XX ~ D_XX, data = subset(df, df$D_XX < quantile(df$D_XX,h,type=2)))$coefficients[["(Intercept)"]])^2
    sigma2 <- reg_1 - reg_2
    h_star_scalars <- c(h_star_scalars, sigma2)

    ## fD2(0)
    bw_density <- lpbwdensity(data = df$D_XX, grid = c(0))$BW[1,2]
    fd_zero <- lpdensity(data = df$D_XX, grid = c(0), bw = bw_density)$Estimate[1,5]
    bw4 <- fd_zero
    h_star_scalars <- c(h_star_scalars, fd_zero)

    ## Matrix to store first constants
    mat_res_XX <- matrix(NA, nrow = 1, ncol = 12)
    colnames(mat_res_XX) <- c("Estimate", "SE", "LB CI", "UB CI", "N", "BW", "N in BW", "V_hat", "BW1", "BW2", "BW3", "BW4")
    rownames(mat_res_XX) <- c(" ")
    
    G_XX <- length(levels(factor(df$group_XX)))
    mat_res_XX[1,5] <- G_XX

    h_star <- ((144*sigma2)/(G_XX*(f_2_prime^2)*fd_zero))^(1/5)
    mat_res_XX[1,6] <- h_star

    h_star_scalars <- c(h_star_scalars, nrow(subset(df, df$D_XX < h_star)))
    # beta_qs
    if (nrow(subset(df, df$D_XX < h_star)) > 0) {
        mu_hat_XX_alt <- lm(diff_Y_XX ~ D_XX, data = subset(df, df$D_XX < h_star))$coefficients[["(Intercept)"]]
        mean_diff_Y_XX <- mean(df$diff_Y_XX, na.rm = TRUE)
        mean_D_XX <- mean(df$D_XX, na.rm = TRUE)
        beta_qs_XX <- (mean_diff_Y_XX - mu_hat_XX_alt) / mean_D_XX
        mat_res_XX[1,1] <- beta_qs_XX

        ## Inference
        df$within_bw_XX <- (df$D_XX <= h_star) 
        df$row_id <- 1:nrow(df)
        levels_groups_h <- levels(factor(subset(df, df$within_bw_XX == 1)$row_id))
        df$resid_XX <- 0
        df$group_XX <- as.numeric(as.character(df$group_XX))

        for (l in levels_groups_h) {
            i <- as.integer(as.character(l))
            local_reg <- lm(diff_Y_XX ~ D_XX, data = subset(df, df$group_XX != df$group_XX[i] & df$D_XX >= df$D_XX[i] - h_star & df$D_XX <= df$D_XX[i] + h_star))
            df$resid_XX[i] <- df$diff_Y_XX[i] - (local_reg$coefficients[1] + local_reg$coefficients[2]*df$D_XX[i])
        }
        df$resid_XX <- as.numeric(df$resid_XX)

        gamma_0_XX <- gamma_1_XX <- gamma_2_XX <- gamma_3_XX <- gamma_4_XX <- NULL
        df$k_h_XX <- df$within_bw_XX / (2 * h_star)
        for (j in 0:4) {
            df$temp <- (df$D_XX^j) * df$k_h_XX
            temp_sum <- mean(df$temp, na.rm = TRUE)
            assign(paste0("gamma_",j,"_XX"), temp_sum/(h_star^j))
            df$temp <- temp_sum <- NULL
        }

        B_hG_XX <- (gamma_2_XX^2 - gamma_1_XX * gamma_3_XX) / (gamma_2_XX * gamma_0_XX - gamma_1_XX^2)
        M_hat_hG_XX <- 0.5 * ((h_star)^2 * f_2_prime * B_hG_XX)
        det_XX <- gamma_0_XX * gamma_2_XX * gamma_4_XX + 2 * gamma_1_XX * gamma_2_XX * gamma_3_XX - gamma_2_XX^3 - gamma_0_XX * gamma_3_XX^2 - gamma_1_XX^2 * gamma_4_XX

        Vec1 <- as.matrix(df$k_h_XX) %*% t(c(gamma_2_XX, - gamma_1_XX))
        Vec2 <- (1/(gamma_2_XX * gamma_0_XX - gamma_1_XX^2)) * as.matrix(t(cbind(matrix(1, nrow(df),1), as.matrix(df$D_XX)/h_star)))
        Vec3 <- (1/det_XX) * c(gamma_2_XX, gamma_3_XX)
        Vec4 <- t(c(gamma_1_XX*gamma_3_XX - gamma_2_XX^2, gamma_0_XX * gamma_3_XX - gamma_1_XX * gamma_2_XX, gamma_0_XX * gamma_2_XX - gamma_1_XX^2))
        Vec5 <- t(cbind(matrix(1, nrow(df),1), as.matrix(df$D_XX)/h_star, as.matrix(df$D_2_XX)/(h_star^2)))

        df$omega_G_g_XX <- diag(Vec1 %*% (Vec2 - Vec3 %*% Vec4 %*% Vec5))
        df$psi_g_XX <- df$omega_G_g_XX * df$resid_XX
        B_hat_hG_XX <- -M_hat_hG_XX / mean_D_XX
        df$phi_g_XX <- sqrt(h_star) * (df$diff_Y_XX - (df$D_XX*mean_diff_Y_XX/mean_D_XX) + ((mu_hat_XX_alt*(df$D_XX-mean_D_XX))/mean_D_XX)- df$psi_g_XX)/mean_D_XX
        
        V_hat_XX <- mean(df$phi_g_XX^2, na.rm = TRUE)
        se_1_XX <- sqrt(V_hat_XX/(h_star * G_XX))
        mat_res_XX[1,2] <- se_1_XX

        lb_XX <- beta_qs_XX - B_hat_hG_XX - qnorm(1 - (level/200)) * se_1_XX
        ub_XX <- beta_qs_XX - B_hat_hG_XX + qnorm(1 - (level/200)) * se_1_XX
        df$within_bw_XX <- as.numeric(df$within_bw_XX)
        N_bw_XX <- sum(df$within_bw_XX, na.rm = TRUE)

        mat_res_XX[1,3] <- lb_XX
        mat_res_XX[1,4] <- ub_XX
        mat_res_XX[1,7] <- N_bw_XX
        mat_res_XX[1,8] <- V_hat_XX
        mat_res_XX[1,9] <- bw1
        mat_res_XX[1,10] <- bw2
        mat_res_XX[1,11] <- bw3
        mat_res_XX[1,12] <- bw4
    }

    df_temp <- df[c("diff_Y_XX", "D_XX")]
    names(df_temp) <- c("diff_Y", "D")
    names(h_star_scalars) <- c("f2_prime", "sigma2", "fd_zero", "N_BW")

    out <- list(mat_res_XX, list(df_temp), h_star_scalars)
    names(out) <- c("mat", "data", "h_scalars")
    return(out)
}